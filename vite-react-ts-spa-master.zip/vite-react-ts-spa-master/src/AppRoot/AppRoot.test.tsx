import { render } from '@testing-library/react';
import AppRoot from './index';

describe('AppRoot.test.tsx', () => {
  it('should render successfully', () => {
    render(<AppRoot />);
  });
});
