import Home from '../Home';

export default function AppRoot() {
  return <Home />;
}
